﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using LinearListApp.Infrastructure;
using LinearListApp.Models;

namespace LinearListApp.ViewModels;

public class MainViewModel : INotifyPropertyChanged
{
    private readonly LinearList<string> _linearList;
    private readonly RelayCommand _addCommand;
    private readonly RelayCommand _removeCommand;
    private readonly RelayCommand _nextCommand;
    private readonly RelayCommand _moveToStartCommand;
    private string _newItemText = string.Empty;
    private string _statusMessage = "Готово к работе";

    public MainViewModel()
    {
        _linearList = new LinearList<string>();
        Items = new ObservableCollection<string>();

        _addCommand = new RelayCommand(_ => AddItem(), _ => !string.IsNullOrWhiteSpace(NewItemText));
        _removeCommand = new RelayCommand(_ => RemoveCurrent(), _ => !_linearList.IsEmpty);
        _nextCommand = new RelayCommand(_ => MoveNext(), _ => !_linearList.IsEmpty);
        _moveToStartCommand = new RelayCommand(_ => MoveToStart(), _ => !_linearList.IsEmpty);
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    public ObservableCollection<string> Items { get; }

    public ICommand AddCommand => _addCommand;

    public ICommand RemoveCommand => _removeCommand;

    public ICommand NextCommand => _nextCommand;

    public ICommand MoveToStartCommand => _moveToStartCommand;

    public string NewItemText
    {
        get => _newItemText;
        set
        {
            if (SetField(ref _newItemText, value))
            {
                _addCommand.RaiseCanExecuteChanged();
            }
        }
    }

    public string CurrentElementText => _linearList.IsEmpty
        ? "Список пуст"
        : _linearList.CurrentElement ?? string.Empty;

    public int Count => _linearList.Count;

    public bool IsEmpty => _linearList.IsEmpty;

    public int CurrentIndex => _linearList.CurrentIndex;

    public string StatusMessage
    {
        get => _statusMessage;
        private set => SetField(ref _statusMessage, value);
    }

    private void AddItem()
    {
        string value = NewItemText.Trim();
        _linearList.Add(value);
        NewItemText = string.Empty;

        RefreshItems();
        RefreshState();
        StatusMessage = $"Элемент '{value}' добавлен";
    }

    private void RemoveCurrent()
    {
        string removedValue = CurrentElementText;

        if (_linearList.RemoveCurrent())
        {
            RefreshItems();
            RefreshState();
            StatusMessage = $"Элемент '{removedValue}' удален";
        }
    }

    private void MoveNext()
    {
        bool moved = _linearList.MoveNext();
        RefreshState();
        StatusMessage = moved ? "Переход к следующему элементу выполнен" : "Следующего элемента нет";
    }

    private void MoveToStart()
    {
        _linearList.MoveToStart();
        RefreshState();
        StatusMessage = "Переход в начало списка выполнен";
    }

    private void RefreshItems()
    {
        Items.Clear();

        foreach (string item in _linearList.GetItems())
        {
            Items.Add(item);
        }
    }

    private void RefreshState()
    {
        OnPropertyChanged(nameof(CurrentElementText));
        OnPropertyChanged(nameof(Count));
        OnPropertyChanged(nameof(IsEmpty));
        OnPropertyChanged(nameof(CurrentIndex));

        _removeCommand.RaiseCanExecuteChanged();
        _nextCommand.RaiseCanExecuteChanged();
        _moveToStartCommand.RaiseCanExecuteChanged();
    }

    private bool SetField<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value))
        {
            return false;
        }

        field = value;
        OnPropertyChanged(propertyName);
        return true;
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
