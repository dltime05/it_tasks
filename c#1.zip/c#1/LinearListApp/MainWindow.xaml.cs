﻿using System.Windows;
using LinearListApp.ViewModels;

namespace LinearListApp;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainViewModel();
    }
}
