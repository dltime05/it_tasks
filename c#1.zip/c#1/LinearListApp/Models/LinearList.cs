﻿namespace LinearListApp.Models;

public class LinearList<T>
{
    private readonly List<T> _items;
    private int _currentIndex;

    public LinearList()
    {
        _items = new List<T>();
        _currentIndex = -1;
    }

    public T? CurrentElement => IsEmpty ? default : _items[_currentIndex];

    public int Count => _items.Count;

    public bool IsEmpty => _items.Count == 0;

    public int CurrentIndex => _currentIndex;

    public void Add(T item)
    {
        _items.Add(item);

        if (_currentIndex == -1)
        {
            _currentIndex = 0;
        }
    }

    public bool RemoveCurrent()
    {
        if (IsEmpty)
        {
            return false;
        }

        _items.RemoveAt(_currentIndex);

        if (IsEmpty)
        {
            _currentIndex = -1;
            return true;
        }

        if (_currentIndex >= _items.Count)
        {
            _currentIndex = _items.Count - 1;
        }

        return true;
    }

    public bool MoveNext()
    {
        if (IsEmpty || _currentIndex >= _items.Count - 1)
        {
            return false;
        }

        _currentIndex++;
        return true;
    }

    public void MoveToStart()
    {
        if (!IsEmpty)
        {
            _currentIndex = 0;
        }
    }

    public IReadOnlyList<T> GetItems()
    {
        return _items.AsReadOnly();
    }
}
