﻿using TransportStopSimulation.Controls;
using TransportStopSimulation.Services;
using TransportStopSimulation.ViewModels;

namespace TransportStopSimulation;

public partial class Form1 : Form
{
    private readonly List<StopSimulationViewModel> _viewModels = new();
    private readonly FlowLayoutPanel _modelsPanel;
    private int _modelCounter;

    public Form1()
    {
        Text = "Моделирование остановки транспорта";
        Width = 940;
        Height = 640;
        StartPosition = FormStartPosition.CenterScreen;

        Panel topPanel = new()
        {
            Dock = DockStyle.Top,
            Height = 56,
            Padding = new Padding(8)
        };

        Button addModelButton = new()
        {
            Text = "Добавить модель",
            Width = 150,
            Height = 34,
            Left = 8,
            Top = 10
        };
        addModelButton.Click += (_, _) => AddNewModel();

        Button startAllButton = new()
        {
            Text = "Старт всех",
            Width = 120,
            Height = 34,
            Left = 170,
            Top = 10
        };
        startAllButton.Click += (_, _) => _viewModels.ForEach(model => model.Start());

        Button stopAllButton = new()
        {
            Text = "Стоп всех",
            Width = 120,
            Height = 34,
            Left = 300,
            Top = 10
        };
        stopAllButton.Click += (_, _) => _viewModels.ForEach(model => model.Stop());

        topPanel.Controls.Add(addModelButton);
        topPanel.Controls.Add(startAllButton);
        topPanel.Controls.Add(stopAllButton);

        _modelsPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            Padding = new Padding(10),
            BackColor = Color.FromArgb(244, 246, 248)
        };

        Controls.Add(_modelsPanel);
        Controls.Add(topPanel);

        AddNewModel();
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        foreach (StopSimulationViewModel viewModel in _viewModels)
        {
            viewModel.Dispose();
        }

        base.OnFormClosing(e);
    }

    private void AddNewModel()
    {
        _modelCounter++;

        StopSimulationModel simulation = new(
            modelId: _modelCounter,
            busCapacity: 12 + (_modelCounter % 4) * 2,
            busSpeed: 1.6f + (_modelCounter % 3) * 0.3f);

        StopSimulationViewModel viewModel = new(simulation);
        SimulationViewControl viewControl = new(viewModel);

        _viewModels.Add(viewModel);
        _modelsPanel.Controls.Add(viewControl);

        viewModel.Start();
    }
}
