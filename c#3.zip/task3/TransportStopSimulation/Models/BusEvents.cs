﻿namespace TransportStopSimulation.Models;

public delegate void BusStoppedHandler(object? sender, BusStoppedEventArgs e);
public delegate void BusOvercrowdedHandler(object? sender, BusOvercrowdedEventArgs e);

public class BusStoppedEventArgs : EventArgs
{
    public BusStoppedEventArgs(int busId, int waitingPassengers)
    {
        BusId = busId;
        WaitingPassengers = waitingPassengers;
    }

    public int BusId { get; }
    public int WaitingPassengers { get; }
}

public class BusOvercrowdedEventArgs : EventArgs
{
    public BusOvercrowdedEventArgs(int busId, int busLoad, int capacity)
    {
        BusId = busId;
        BusLoad = busLoad;
        Capacity = capacity;
    }

    public int BusId { get; }
    public int BusLoad { get; }
    public int Capacity { get; }
}
