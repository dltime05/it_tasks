﻿namespace TransportStopSimulation.Models;

public class TouristPassenger : IPassenger
{
    public string Category => "Турист";
    public int BoardingTimeMs => 500;
}
