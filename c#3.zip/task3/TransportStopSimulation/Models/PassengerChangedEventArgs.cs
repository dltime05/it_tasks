﻿namespace TransportStopSimulation.Models;

public class PassengerChangedEventArgs : EventArgs
{
    public PassengerChangedEventArgs(IPassenger passenger)
    {
        Passenger = passenger;
    }

    public IPassenger Passenger { get; }
}
