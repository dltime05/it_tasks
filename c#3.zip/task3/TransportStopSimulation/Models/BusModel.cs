﻿namespace TransportStopSimulation.Models;

public class BusModel
{
    private readonly List<IPassenger> _passengers = new();
    private readonly object _sync = new();

    private bool _stoppedThisRoute;
    private int _stopTicksLeft;

    public BusModel(int id, int capacity, float speedPerTick)
    {
        Id = id;
        Capacity = capacity;
        SpeedPerTick = speedPerTick;
    }

    public event BusStoppedHandler? BusStoppedAtStop;
    public event BusOvercrowdedHandler? BusOvercrowded;

    public int Id { get; }
    public int Capacity { get; }
    public float SpeedPerTick { get; }

    public float Position { get; private set; }

    public int PassengerCount
    {
        get
        {
            lock (_sync)
            {
                return _passengers.Count;
            }
        }
    }

    public bool Tick(float routeLength, float stopPosition, int stopDurationTicks, Random random)
    {
        if (_stopTicksLeft > 0)
        {
            _stopTicksLeft--;
            return false;
        }

        Position += SpeedPerTick;

        if (Position >= routeLength)
        {
            Position = 0;
            _stoppedThisRoute = false;
            DropOffPassengers(random);
        }

        if (!_stoppedThisRoute && Math.Abs(Position - stopPosition) <= SpeedPerTick)
        {
            _stoppedThisRoute = true;
            _stopTicksLeft = stopDurationTicks;
            BusStoppedAtStop?.Invoke(this, new BusStoppedEventArgs(Id, 0));
            return true;
        }

        return false;
    }

    public int BoardPassengers(StopModel stop)
    {
        int boarded = 0;

        while (true)
        {
            IPassenger? candidate;
            lock (_sync)
            {
                if (_passengers.Count >= Capacity)
                {
                    break;
                }
            }

            if (!stop.TryBoardPassenger(out candidate) || candidate is null)
            {
                break;
            }

            lock (_sync)
            {
                _passengers.Add(candidate);
                boarded++;
            }
        }

        if (PassengerCount >= Capacity && stop.WaitingCount > 0)
        {
            BusOvercrowded?.Invoke(this, new BusOvercrowdedEventArgs(Id, PassengerCount, Capacity));
        }

        return boarded;
    }

    private void DropOffPassengers(Random random)
    {
        lock (_sync)
        {
            if (_passengers.Count == 0)
            {
                return;
            }

            int passengersToLeave = random.Next(0, _passengers.Count + 1);
            if (passengersToLeave > 0)
            {
                _passengers.RemoveRange(0, passengersToLeave);
            }
        }
    }
}
