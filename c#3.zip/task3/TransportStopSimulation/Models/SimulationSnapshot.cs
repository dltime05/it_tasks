﻿namespace TransportStopSimulation.Models;

public class SimulationSnapshot
{
    public int ModelId { get; init; }
    public float BusPosition { get; init; }
    public float RouteLength { get; init; }
    public float StopPosition { get; init; }
    public int WaitingPassengers { get; init; }
    public int BusLoad { get; init; }
    public int BusCapacity { get; init; }
    public bool OvercrowdedFlag { get; init; }
    public int StopsCount { get; init; }
    public int OvercrowdedCount { get; init; }
    public double OvercrowdedPercent { get; init; }
    public string LastMessage { get; init; } = string.Empty;
    public Dictionary<string, int> WaitingByType { get; init; } = new();
}
