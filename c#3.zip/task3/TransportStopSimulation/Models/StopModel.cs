﻿using System.Collections.Concurrent;

namespace TransportStopSimulation.Models;

public class StopModel
{
    private readonly ConcurrentQueue<IPassenger> _passengers = new();

    public event EventHandler<PassengerChangedEventArgs>? PassengerAdded;
    public event EventHandler<PassengerChangedEventArgs>? PassengerBoarded;

    public int WaitingCount => _passengers.Count;

    public void AddPassenger(IPassenger passenger)
    {
        _passengers.Enqueue(passenger);
        PassengerAdded?.Invoke(this, new PassengerChangedEventArgs(passenger));
    }

    public bool TryBoardPassenger(out IPassenger? passenger)
    {
        if (_passengers.TryDequeue(out IPassenger? candidate))
        {
            passenger = candidate;
            PassengerBoarded?.Invoke(this, new PassengerChangedEventArgs(candidate));
            return true;
        }

        passenger = null;
        return false;
    }

    public Dictionary<string, int> GetPassengerTypeStats()
    {
        Dictionary<string, int> stats = new();
        foreach (IPassenger passenger in _passengers)
        {
            if (!stats.ContainsKey(passenger.Category))
            {
                stats[passenger.Category] = 0;
            }

            stats[passenger.Category]++;
        }

        return stats;
    }
}
