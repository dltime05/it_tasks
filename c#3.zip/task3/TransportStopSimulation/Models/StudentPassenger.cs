﻿namespace TransportStopSimulation.Models;

public class StudentPassenger : IPassenger
{
    public string Category => "Студент";
    public int BoardingTimeMs => 350;
}
