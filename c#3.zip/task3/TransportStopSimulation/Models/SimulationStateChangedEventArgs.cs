﻿namespace TransportStopSimulation.Models;

public class SimulationStateChangedEventArgs : EventArgs
{
    public SimulationStateChangedEventArgs(SimulationSnapshot snapshot)
    {
        Snapshot = snapshot;
    }

    public SimulationSnapshot Snapshot { get; }
}
