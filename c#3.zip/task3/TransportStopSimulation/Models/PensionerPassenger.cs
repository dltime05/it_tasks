﻿namespace TransportStopSimulation.Models;

public class PensionerPassenger : IPassenger
{
    public string Category => "Пенсионер";
    public int BoardingTimeMs => 600;
}
