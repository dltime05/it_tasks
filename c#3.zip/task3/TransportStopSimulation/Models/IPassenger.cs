﻿namespace TransportStopSimulation.Models;

public interface IPassenger
{
    string Category { get; }
    int BoardingTimeMs { get; }
}
