﻿using TransportStopSimulation.Models;

namespace TransportStopSimulation.Services;

public class StopSimulationModel : IDisposable
{
    private const float RouteLength = 100f;
    private const float StopPosition = 50f;
    private const int StopDurationTicks = 18;
    private const double PassengerSpawnProbability = 0.06;

    private readonly Random _random;
    private readonly PassengerFactory _passengerFactory;

    private CancellationTokenSource? _cancellationTokenSource;
    private Task? _simulationTask;
    private string _lastMessage = "Ожидание запуска";
    private int _overcrowdedTicks;
    private int _stopsCount;
    private int _overcrowdedCount;

    public StopSimulationModel(int modelId, int busCapacity, float busSpeed)
    {
        ModelId = modelId;
        _random = new Random(Guid.NewGuid().GetHashCode());
        _passengerFactory = new PassengerFactory();

        Stop = new StopModel();
        Bus = new BusModel(modelId, busCapacity, busSpeed);

        Bus.BusStoppedAtStop += HandleBusStopped;
        Bus.BusOvercrowded += HandleBusOvercrowded;
    }

    public event EventHandler<SimulationStateChangedEventArgs>? StateChanged;

    public int ModelId { get; }
    public StopModel Stop { get; }
    public BusModel Bus { get; }

    public void Start()
    {
        if (_simulationTask is { IsCompleted: false })
        {
            return;
        }

        _cancellationTokenSource = new CancellationTokenSource();
        CancellationToken token = _cancellationTokenSource.Token;

        _simulationTask = Task.Run(async () =>
        {
            while (!token.IsCancellationRequested)
            {
                if (_random.NextDouble() < PassengerSpawnProbability)
                {
                    Stop.AddPassenger(_passengerFactory.CreateRandomPassenger(_random));
                }

                Bus.Tick(RouteLength, StopPosition, StopDurationTicks, _random);

                if (_overcrowdedTicks > 0)
                {
                    _overcrowdedTicks--;
                }

                PublishState();

                await Task.Delay(60, token);
            }
        }, token);
    }

    public void StopSimulation()
    {
        if (_cancellationTokenSource is null)
        {
            return;
        }

        _cancellationTokenSource.Cancel();
        _lastMessage = "Остановлено";
    }

    public void Dispose()
    {
        StopSimulation();
        Bus.BusStoppedAtStop -= HandleBusStopped;
        Bus.BusOvercrowded -= HandleBusOvercrowded;
        _cancellationTokenSource?.Dispose();
    }

    private void HandleBusStopped(object? sender, BusStoppedEventArgs e)
    {
        _stopsCount++;
        int boarded = Bus.BoardPassengers(Stop);
        _lastMessage = $"Автобус остановился, вошло: {boarded}";
    }

    private void HandleBusOvercrowded(object? sender, BusOvercrowdedEventArgs e)
    {
        _overcrowdedCount++;
        _overcrowdedTicks = 30;
        _lastMessage = $"Переполнение остановки: автобус {e.BusId} полный ({e.BusLoad}/{e.Capacity}), очередь осталась";
    }

    private void PublishState()
    {
        SimulationSnapshot snapshot = new()
        {
            ModelId = ModelId,
            BusPosition = Bus.Position,
            RouteLength = RouteLength,
            StopPosition = StopPosition,
            WaitingPassengers = Stop.WaitingCount,
            BusLoad = Bus.PassengerCount,
            BusCapacity = Bus.Capacity,
            OvercrowdedFlag = _overcrowdedTicks > 0,
            StopsCount = _stopsCount,
            OvercrowdedCount = _overcrowdedCount,
            OvercrowdedPercent = _stopsCount == 0 ? 0 : (double)_overcrowdedCount * 100 / _stopsCount,
            LastMessage = _lastMessage,
            WaitingByType = Stop.GetPassengerTypeStats()
        };

        StateChanged?.Invoke(this, new SimulationStateChangedEventArgs(snapshot));
    }
}
