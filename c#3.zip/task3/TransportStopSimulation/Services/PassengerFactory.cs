﻿using System.Reflection;
using TransportStopSimulation.Models;

namespace TransportStopSimulation.Services;

public class PassengerFactory
{
    private readonly List<Type> _passengerTypes;

    public PassengerFactory()
    {
        _passengerTypes = Assembly.GetExecutingAssembly()
            .GetTypes()
            .Where(type => typeof(IPassenger).IsAssignableFrom(type))
            .Where(type => !type.IsAbstract && !type.IsInterface)
            .ToList();

        if (_passengerTypes.Count == 0)
        {
            throw new InvalidOperationException("Не найдены классы пассажиров.");
        }
    }

    public IPassenger CreateRandomPassenger(Random random)
    {
        int index = random.Next(0, _passengerTypes.Count);
        Type selectedType = _passengerTypes[index];
        return (IPassenger)Activator.CreateInstance(selectedType)!;
    }
}
