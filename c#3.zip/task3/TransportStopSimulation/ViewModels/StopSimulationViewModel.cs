﻿using TransportStopSimulation.Models;
using TransportStopSimulation.Services;

namespace TransportStopSimulation.ViewModels;

public class StopSimulationViewModel : IDisposable
{
    private SimulationSnapshot _snapshot;

    public StopSimulationViewModel(StopSimulationModel simulation)
    {
        Simulation = simulation;
        _snapshot = new SimulationSnapshot
        {
            ModelId = simulation.ModelId,
            RouteLength = 100f,
            StopPosition = 50f,
            LastMessage = "Модель создана"
        };

        Simulation.StateChanged += HandleStateChanged;
    }

    public event EventHandler? SnapshotChanged;

    public StopSimulationModel Simulation { get; }

    public SimulationSnapshot Snapshot => _snapshot;

    public void Start()
    {
        Simulation.Start();
    }

    public void Stop()
    {
        Simulation.StopSimulation();
    }

    public void Dispose()
    {
        Simulation.StateChanged -= HandleStateChanged;
        Simulation.Dispose();
    }

    private void HandleStateChanged(object? sender, SimulationStateChangedEventArgs e)
    {
        _snapshot = e.Snapshot;
        SnapshotChanged?.Invoke(this, EventArgs.Empty);
    }
}
