﻿using System.Drawing.Drawing2D;
using TransportStopSimulation.Models;
using TransportStopSimulation.ViewModels;

namespace TransportStopSimulation.Controls;

public class SimulationViewControl : UserControl
{
    private readonly StopSimulationViewModel _viewModel;

    public SimulationViewControl(StopSimulationViewModel viewModel)
    {
        _viewModel = viewModel;

        DoubleBuffered = true;
        Width = 420;
        Height = 220;
        Margin = new Padding(8);
        BackColor = Color.WhiteSmoke;

        _viewModel.SnapshotChanged += HandleSnapshotChanged;
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _viewModel.SnapshotChanged -= HandleSnapshotChanged;
        }

        base.Dispose(disposing);
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);

        e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
        SimulationSnapshot snapshot = _viewModel.Snapshot;

        int left = 16;
        int right = Width - 16;
        int roadY = Height - 55;

        using Pen roadPen = new(Color.DimGray, 4);
        using Pen stopPen = new(Color.SteelBlue, 5);
        using Brush busBrush = new SolidBrush(snapshot.OvercrowdedFlag ? Color.IndianRed : Color.SeaGreen);
        using Brush queueBrush = new SolidBrush(Color.Goldenrod);
        using Brush textBrush = new SolidBrush(Color.Black);

        e.Graphics.DrawLine(roadPen, left, roadY, right, roadY);

        float routeSpan = Math.Max(1f, snapshot.RouteLength);
        float busRatio = snapshot.BusPosition / routeSpan;
        int busX = left + (int)((right - left) * busRatio);
        int stopX = left + (int)((right - left) * (snapshot.StopPosition / routeSpan));

        Rectangle busRectangle = new(busX - 18, roadY - 26, 36, 20);
        e.Graphics.FillRectangle(busBrush, busRectangle);
        e.Graphics.DrawRectangle(Pens.Black, busRectangle);

        e.Graphics.DrawLine(stopPen, stopX, roadY - 38, stopX, roadY + 2);
        e.Graphics.DrawString("Остановка", Font, textBrush, stopX - 28, roadY - 56);

        int circles = Math.Min(10, snapshot.WaitingPassengers);
        for (int i = 0; i < circles; i++)
        {
            e.Graphics.FillEllipse(queueBrush, stopX + 10 + i * 11, roadY - 20, 8, 8);
        }

        e.Graphics.DrawString($"Модель #{snapshot.ModelId}", Font, textBrush, left, 8);
        e.Graphics.DrawString($"В очереди: {snapshot.WaitingPassengers}", Font, textBrush, left, 28);
        e.Graphics.DrawString($"В автобусе: {snapshot.BusLoad}/{snapshot.BusCapacity}", Font, textBrush, left, 46);
        e.Graphics.DrawString(snapshot.LastMessage, Font, textBrush, left, 64);
        e.Graphics.DrawString(
            $"Событий переполнения остановки: {snapshot.OvercrowdedCount} из {snapshot.StopsCount}",
            Font,
            textBrush,
            left,
            84);
        e.Graphics.DrawString(
            $"Процент переполнения остановки: {snapshot.OvercrowdedPercent:F1}%",
            Font,
            textBrush,
            left,
            102);

        string types = string.Join(", ", snapshot.WaitingByType.Select(pair => $"{pair.Key}:{pair.Value}"));
        if (!string.IsNullOrWhiteSpace(types))
        {
            e.Graphics.DrawString(types, Font, textBrush, left, 122);
        }
    }

    private void HandleSnapshotChanged(object? sender, EventArgs e)
    {
        if (!IsHandleCreated)
        {
            return;
        }

        BeginInvoke(() => Invalidate());
    }
}
