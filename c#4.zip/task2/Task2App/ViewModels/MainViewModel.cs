using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using System.Windows.Input;
using CreatureContracts;
using Microsoft.Win32;
using Task2App.Infrastructure;

namespace Task2App.ViewModels;

public class MainViewModel : INotifyPropertyChanged
{
    private string _libraryPath = string.Empty;
    private CreatureTypeViewModel? _selectedCreatureType;
    private CreatureMethodViewModel? _selectedMethod;
    private ConstructorInfo? _selectedConstructor;
    private string _classInformation = "Загрузите библиотеку классов.";
    private string _executionResult = string.Empty;
    private Assembly? _loadedAssembly;

    public ObservableCollection<CreatureTypeViewModel> CreatureTypes { get; } = [];

    public ObservableCollection<ParameterInputViewModel> ConstructorParameters { get; } = [];

    public string LibraryPath
    {
        get => _libraryPath;
        set
        {
            _libraryPath = value;
            OnPropertyChanged();
            RaiseLoadStateChanged();
        }
    }

    public CreatureTypeViewModel? SelectedCreatureType
    {
        get => _selectedCreatureType;
        set
        {
            _selectedCreatureType = value;
            OnPropertyChanged();
            LoadSelectedTypeDetails();
        }
    }

    public CreatureMethodViewModel? SelectedMethod
    {
        get => _selectedMethod;
        set
        {
            _selectedMethod = value;
            OnPropertyChanged();
            RaiseExecuteStateChanged();
        }
    }

    public string ClassInformation
    {
        get => _classInformation;
        private set
        {
            _classInformation = value;
            OnPropertyChanged();
        }
    }

    public string ExecutionResult
    {
        get => _executionResult;
        private set
        {
            _executionResult = value;
            OnPropertyChanged();
        }
    }

    public ICommand BrowseLibraryCommand { get; }
    public ICommand LoadLibraryCommand { get; }
    public ICommand ExecuteMethodCommand { get; }

    public MainViewModel()
    {
        LibraryPath = GetDefaultLibraryPath();

        BrowseLibraryCommand = new RelayCommand(BrowseLibrary);
        LoadLibraryCommand = new RelayCommand(LoadLibrary, () => !string.IsNullOrWhiteSpace(LibraryPath));
        ExecuteMethodCommand = new RelayCommand(ExecuteSelectedMethod, CanExecuteSelectedMethod);

        LoadLibrary();
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private static string GetDefaultLibraryPath()
    {
        return Path.Combine(AppContext.BaseDirectory, "CreatureLibrary.dll");
    }

    private void BrowseLibrary()
    {
        var dialog = new OpenFileDialog
        {
            Filter = "Библиотеки .NET (*.dll)|*.dll|Все файлы (*.*)|*.*",
            FileName = Path.GetFileName(LibraryPath),
            InitialDirectory = Directory.Exists(Path.GetDirectoryName(LibraryPath))
                ? Path.GetDirectoryName(LibraryPath)
                : AppContext.BaseDirectory
        };

        if (dialog.ShowDialog() == true)
        {
            LibraryPath = dialog.FileName;
            LoadLibrary();
        }
    }

    private void LoadLibrary()
    {
        CreatureTypes.Clear();
        ConstructorParameters.Clear();
        SelectedMethod = null;
        SelectedCreatureType = null;
        ExecutionResult = string.Empty;

        if (!File.Exists(LibraryPath))
        {
            ClassInformation = "Файл библиотеки не найден.";
            return;
        }

        try
        {
            RegisterDependencyResolver(Path.GetDirectoryName(LibraryPath));
            _loadedAssembly = Assembly.LoadFrom(LibraryPath);

            var types = _loadedAssembly.GetTypes()
                .Where(type => typeof(ILivingCreature).IsAssignableFrom(type))
                .Where(type => type is { IsClass: true, IsAbstract: false })
                .OrderBy(type => type.Name);

            foreach (var type in types)
            {
                CreatureTypes.Add(new CreatureTypeViewModel(type));
            }

            ClassInformation = CreatureTypes.Count == 0
                ? "В библиотеке не найдены классы, реализующие ILivingCreature."
                : $"Найдено классов: {CreatureTypes.Count}.";
        }
        catch (Exception exception)
        {
            ClassInformation = $"Ошибка загрузки библиотеки: {exception.Message}";
        }
    }

    private static void RegisterDependencyResolver(string? libraryDirectory)
    {
        if (string.IsNullOrWhiteSpace(libraryDirectory))
        {
            return;
        }

        AssemblyLoadContext.Default.Resolving += (_, assemblyName) =>
        {
            var dependencyPath = Path.Combine(libraryDirectory, $"{assemblyName.Name}.dll");
            return File.Exists(dependencyPath) ? Assembly.LoadFrom(dependencyPath) : null;
        };
    }

    private void LoadSelectedTypeDetails()
    {
        ConstructorParameters.Clear();
        SelectedMethod = null;
        ExecutionResult = string.Empty;

        if (SelectedCreatureType == null)
        {
            ClassInformation = "Выберите класс.";
            RaiseExecuteStateChanged();
            return;
        }

        _selectedConstructor = SelectedCreatureType.Type
            .GetConstructors()
            .OrderByDescending(constructor => constructor.GetParameters().Length)
            .FirstOrDefault();

        if (_selectedConstructor != null)
        {
            foreach (var parameter in _selectedConstructor.GetParameters())
            {
                ConstructorParameters.Add(ParameterInputViewModel.ForConstructor(parameter, SelectedCreatureType.Name));
            }
        }

        ClassInformation = BuildClassInformation(SelectedCreatureType.Type);
        RaiseExecuteStateChanged();
    }

    private static string BuildClassInformation(Type type)
    {
        var properties = string.Join(Environment.NewLine, type.GetProperties()
            .Where(property => property.GetMethod?.IsPublic == true)
            .Select(property => $"Свойство: {property.PropertyType.Name} {property.Name}"));

        var methods = string.Join(Environment.NewLine, GetCallableMethods(type)
            .Select(method => $"Метод: {GetMethodSignature(method)}"));

        var events = string.Join(Environment.NewLine, type.GetEvents()
            .Select(eventInfo => $"Событие: {eventInfo.EventHandlerType?.Name} {eventInfo.Name}"));

        return string.Join(Environment.NewLine, new[] { type.FullName, properties, methods, events }
            .Where(part => !string.IsNullOrWhiteSpace(part)));
    }

    private static IEnumerable<MethodInfo> GetCallableMethods(Type type)
    {
        return type.GetMethods(BindingFlags.Public | BindingFlags.Instance)
            .Where(method => !method.IsSpecialName)
            .Where(method => method.DeclaringType != typeof(object))
            .OrderBy(method => method.Name);
    }

    private static string GetMethodSignature(MethodInfo method)
    {
        var parameters = string.Join(", ", method.GetParameters()
            .Select(parameter => $"{parameter.ParameterType.Name} {parameter.Name}"));

        return $"{method.ReturnType.Name} {method.Name}({parameters})";
    }

    private bool CanExecuteSelectedMethod()
    {
        return SelectedCreatureType != null && SelectedMethod != null && _selectedConstructor != null;
    }

    private void ExecuteSelectedMethod()
    {
        if (SelectedCreatureType == null || SelectedMethod == null || _selectedConstructor == null)
        {
            return;
        }

        try
        {
            var constructorArguments = ConvertParameterValues(ConstructorParameters);
            var creature = _selectedConstructor.Invoke(constructorArguments);
            var eventMessages = SubscribeToStringEvents(creature, SelectedCreatureType.Type);
            var methodArguments = ConvertParameterValues(SelectedMethod.Parameters);
            var returnValue = SelectedMethod.Method.Invoke(creature, methodArguments);

            ExecutionResult = BuildExecutionResult(creature, returnValue, eventMessages);
        }
        catch (Exception exception)
        {
            var actualException = exception is TargetInvocationException invocationException
                ? invocationException.InnerException ?? exception
                : exception;

            ExecutionResult = $"Ошибка выполнения: {actualException.Message}";
        }
    }

    private static object?[] ConvertParameterValues(IEnumerable<ParameterInputViewModel> parameters)
    {
        return parameters
            .Select(parameter => ConvertValue(parameter.Value, parameter.ParameterType))
            .ToArray();
    }

    private static object? ConvertValue(string value, Type targetType)
    {
        var actualType = Nullable.GetUnderlyingType(targetType) ?? targetType;

        if (actualType == typeof(string))
        {
            return value;
        }

        if (actualType.IsEnum)
        {
            return Enum.Parse(actualType, value, ignoreCase: true);
        }

        return Convert.ChangeType(value, actualType, CultureInfo.CurrentCulture);
    }

    private static List<string> SubscribeToStringEvents(object creature, Type creatureType)
    {
        var messages = new List<string>();
        EventHandler<string> handler = (_, message) => messages.Add(message);

        foreach (var eventInfo in creatureType.GetEvents().Where(e => e.EventHandlerType == typeof(EventHandler<string>)))
        {
            eventInfo.AddEventHandler(creature, handler);
        }

        return messages;
    }

    private static string BuildExecutionResult(object creature, object? returnValue, IReadOnlyCollection<string> eventMessages)
    {
        var lines = new List<string>();

        if (eventMessages.Count > 0)
        {
            lines.AddRange(eventMessages);
        }

        if (returnValue != null)
        {
            lines.Add($"Возвращаемое значение: {returnValue}");
        }

        if (creature is ILivingCreature livingCreature)
        {
            lines.Add($"Объект: {livingCreature.Name}");
            lines.Add($"Скорость: {livingCreature.Speed} / {livingCreature.MaxSpeed}");
        }

        return lines.Count == 0
            ? "Метод выполнен."
            : string.Join(Environment.NewLine, lines);
    }

    private void RaiseExecuteStateChanged()
    {
        if (ExecuteMethodCommand is RelayCommand executeCommand)
        {
            executeCommand.RaiseCanExecuteChanged();
        }
    }

    private void RaiseLoadStateChanged()
    {
        if (LoadLibraryCommand is RelayCommand loadCommand)
        {
            loadCommand.RaiseCanExecuteChanged();
        }
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public sealed class CreatureTypeViewModel
    {
        public CreatureTypeViewModel(Type type)
        {
            Type = type;
            Name = type.Name;

            foreach (var method in GetCallableMethods(type))
            {
                Methods.Add(new CreatureMethodViewModel(method));
            }
        }

        public Type Type { get; }

        public string Name { get; }

        public ObservableCollection<CreatureMethodViewModel> Methods { get; } = [];
    }

    public sealed class CreatureMethodViewModel
    {
        public CreatureMethodViewModel(MethodInfo method)
        {
            Method = method;
            Name = GetMethodSignature(method);

            foreach (var parameter in method.GetParameters())
            {
                Parameters.Add(ParameterInputViewModel.ForMethod(parameter));
            }
        }

        public MethodInfo Method { get; }

        public string Name { get; }

        public ObservableCollection<ParameterInputViewModel> Parameters { get; } = [];
    }

    public sealed class ParameterInputViewModel
    {
        private ParameterInputViewModel(ParameterInfo parameter, string caption, string value)
        {
            Caption = caption;
            ParameterType = parameter.ParameterType;
            Value = value;
        }

        public string Caption { get; }

        public Type ParameterType { get; }

        public string Value { get; set; }

        public static ParameterInputViewModel ForConstructor(ParameterInfo parameter, string typeName)
        {
            var defaultValue = parameter.ParameterType == typeof(string) && parameter.Name == "name"
                ? typeName
                : GetDefaultValue(parameter);

            return new ParameterInputViewModel(parameter, $"{parameter.Name} ({parameter.ParameterType.Name})", defaultValue);
        }

        public static ParameterInputViewModel ForMethod(ParameterInfo parameter)
        {
            return new ParameterInputViewModel(parameter, $"{parameter.Name} ({parameter.ParameterType.Name})", GetDefaultValue(parameter));
        }

        private static string GetDefaultValue(ParameterInfo parameter)
        {
            if (parameter.HasDefaultValue && parameter.DefaultValue != null)
            {
                return parameter.DefaultValue.ToString() ?? string.Empty;
            }

            return parameter.ParameterType == typeof(string) ? string.Empty : "0";
        }
    }
}
