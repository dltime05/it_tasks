namespace CreatureContracts;

public interface ILivingCreature
{
    string Name { get; }
    int Speed { get; }
    int MaxSpeed { get; }
    int SpeedStep { get; }

    void Move();
    void Stand();
}
