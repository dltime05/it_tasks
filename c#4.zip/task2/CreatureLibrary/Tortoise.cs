namespace CreatureLibrary;

public class Tortoise : LivingCreature
{
    public Tortoise(string name, int maxSpeed, int speedStep)
        : base(name, maxSpeed, speedStep)
    {
    }

    public override void Move()
    {
        IncreaseSpeed();
    }

    public override void Stand()
    {
        DecreaseSpeed();
    }
}
