using CreatureContracts;

namespace CreatureLibrary;

public abstract class LivingCreature : ILivingCreature
{
    public string Name { get; }
    public int Speed { get; private set; }
    public int MaxSpeed { get; }
    public int SpeedStep { get; }

    protected LivingCreature(string name, int maxSpeed, int speedStep)
    {
        Name = name;
        MaxSpeed = maxSpeed;
        SpeedStep = speedStep;
        Speed = 0;
    }

    public abstract void Move();

    public abstract void Stand();

    protected void IncreaseSpeed()
    {
        Speed += SpeedStep;

        if (Speed > MaxSpeed)
        {
            Speed = MaxSpeed;
        }
    }

    protected void DecreaseSpeed()
    {
        Speed -= SpeedStep;

        if (Speed < 0)
        {
            Speed = 0;
        }
    }
}
