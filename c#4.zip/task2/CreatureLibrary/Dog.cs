namespace CreatureLibrary;

public class Dog : LivingCreature
{
    public event EventHandler<string>? VoiceGiven;

    public Dog(string name, int maxSpeed, int speedStep)
        : base(name, maxSpeed, speedStep)
    {
    }

    public override void Move()
    {
        IncreaseSpeed();
    }

    public override void Stand()
    {
        DecreaseSpeed();
    }

    public void GiveVoice()
    {
        VoiceGiven?.Invoke(this, $"{Name}: гав-гав!");
    }
}
