using System.Windows;
using Task2App.ViewModels;

namespace Task2App;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        DataContext = new MainViewModel();
    }
}
