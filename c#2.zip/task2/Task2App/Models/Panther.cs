namespace Task2App.Models;

public class Panther : LivingCreature
{
    public event EventHandler<string>? VoiceGiven;
    public event EventHandler<string>? TreeClimbed;

    public Panther(string name, int maxSpeed, int speedStep)
        : base(name, maxSpeed, speedStep)
    {
    }

    public override void Move()
    {
        IncreaseSpeed();
    }

    public override void Stand()
    {
        DecreaseSpeed();
    }

    public void GiveVoice()
    {
        VoiceGiven?.Invoke(this, $"{Name}: р-р-р!");
    }

    public void ClimbTree()
    {
        TreeClimbed?.Invoke(this, $"{Name} залезла на дерево.");
    }
}
