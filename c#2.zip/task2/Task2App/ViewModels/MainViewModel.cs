using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Task2App.Infrastructure;
using Task2App.Models;

namespace Task2App.ViewModels;

public class MainViewModel : INotifyPropertyChanged
{
    private LivingCreature? _selectedCreature;
    private string _lastAction = "Выберите животное.";

    public ObservableCollection<LivingCreature> Creatures { get; }

    public LivingCreature? SelectedCreature
    {
        get => _selectedCreature;
        set
        {
            _selectedCreature = value;
            OnPropertyChanged();
            OnPropertyChanged(nameof(CurrentSpeed));
            OnPropertyChanged(nameof(MaxSpeed));
            UpdateCommands();
        }
    }

    public int CurrentSpeed => SelectedCreature?.Speed ?? 0;

    public int MaxSpeed => SelectedCreature?.MaxSpeed ?? 0;

    public string LastAction
    {
        get => _lastAction;
        private set
        {
            _lastAction = value;
            OnPropertyChanged();
        }
    }

    public ICommand MoveCommand { get; }
    public ICommand StandCommand { get; }
    public ICommand VoiceCommand { get; }
    public ICommand ClimbTreeCommand { get; }

    public MainViewModel()
    {
        // Инициализация значений снаружи классов моделей (по условию задания)
        var panther = new Panther("Пантера", maxSpeed: 60, speedStep: 15);
        var dog = new Dog("Собака", maxSpeed: 45, speedStep: 10);
        var tortoise = new Tortoise("Черепаха", maxSpeed: 8, speedStep: 2);

        panther.VoiceGiven += OnAnimalMessage;
        panther.TreeClimbed += OnAnimalMessage;
        dog.VoiceGiven += OnAnimalMessage;

        Creatures = new ObservableCollection<LivingCreature> { panther, dog, tortoise };
        SelectedCreature = Creatures[0];

        MoveCommand = new RelayCommand(Move, () => SelectedCreature != null);
        StandCommand = new RelayCommand(Stand, () => SelectedCreature != null);
        VoiceCommand = new RelayCommand(GiveVoice, CanGiveVoice);
        ClimbTreeCommand = new RelayCommand(ClimbTree, () => SelectedCreature is Panther);
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    private void Move()
    {
        if (SelectedCreature == null)
        {
            return;
        }

        SelectedCreature.Move();
        LastAction = $"{SelectedCreature.Name} движется.";
        OnPropertyChanged(nameof(CurrentSpeed));
    }

    private void Stand()
    {
        if (SelectedCreature == null)
        {
            return;
        }

        SelectedCreature.Stand();
        LastAction = $"{SelectedCreature.Name} стоит.";
        OnPropertyChanged(nameof(CurrentSpeed));
    }

    private void GiveVoice()
    {
        if (SelectedCreature is Panther panther)
        {
            panther.GiveVoice();
            return;
        }

        if (SelectedCreature is Dog dog)
        {
            dog.GiveVoice();
        }
    }

    private bool CanGiveVoice()
    {
        return SelectedCreature is Panther || SelectedCreature is Dog;
    }

    private void ClimbTree()
    {
        if (SelectedCreature is Panther panther)
        {
            panther.ClimbTree();
        }
    }

    private void OnAnimalMessage(object? sender, string message)
    {
        LastAction = message;
    }

    private void UpdateCommands()
    {
        if (MoveCommand is RelayCommand moveCommand)
        {
            moveCommand.RaiseCanExecuteChanged();
        }

        if (StandCommand is RelayCommand standCommand)
        {
            standCommand.RaiseCanExecuteChanged();
        }

        if (VoiceCommand is RelayCommand voiceCommand)
        {
            voiceCommand.RaiseCanExecuteChanged();
        }

        if (ClimbTreeCommand is RelayCommand climbTreeCommand)
        {
            climbTreeCommand.RaiseCanExecuteChanged();
        }
    }

    private void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}
